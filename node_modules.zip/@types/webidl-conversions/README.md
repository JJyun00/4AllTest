# Installation
> `npm install --save @types/webidl-conversions`

# Summary
This package contains type definitions for webidl-conversions (https://github.com/jsdom/webidl-conversions#readme).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/webidl-conversions.

### Additional Details
 * Last updated: Mon, 29 Aug 2022 23:32:44 GMT
 * Dependencies: none
 * Global values: none

# Credits
These definitions were written by [ExE Boss](https://github.com/ExE-Boss), and [BendingBender](https://github.com/BendingBender).
